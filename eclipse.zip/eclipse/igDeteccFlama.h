/*
 * igDeteccFlama.h
 *
 *  Created on: Dec 7, 2020
 *      Author: jcaf
 */

#ifndef IGDETECCFLAMA_H_
#define IGDETECCFLAMA_H_

void igDeteccFlama_resetJob(void);

int8_t igDeteccFlama_doJob(void);


#endif /* IGDETECCFLAMA_H_ */
