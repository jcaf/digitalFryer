/*
 * igDeteccFlama.c
 *
 *  Created on: Dec 1, 2020
 *      Author: jcaf
 */
#include "main.h"

void igDeteccFlama_resetJob(void)
{

}
int8_t igDeteccFlama_doJob(void)
{
	return 1;
}
