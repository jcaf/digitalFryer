/*
 * lcdserver.c
 *
 *  Created on: Aug 24, 2021
 *      Author: jcaf
 */
#include "../lcdan/lcdan.h"
/*
struct _dispsvr
{
	char dispsvrBuff[LCDAN_ROW][LCDAN_COL];
	struct _dispsvr_bf
	{
		unsigned update:1;
		unsigned __a:7;
	}bf;
}dispsvr;

void dispsvr_job(void)
{
	if (dispsvr.bf.update)
	{
		dispsvr.bf.update = 0;
		//



		//
	}
}

*/
