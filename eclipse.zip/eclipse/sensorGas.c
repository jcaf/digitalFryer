/*
 * sensorGas.c
 *
 *  Created on: Dec 1, 2020
 *      Author: jcaf
 */
#include "main.h"

int8_t sensorGas_job(void)
{
	return 1;
}
