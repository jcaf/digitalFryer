/*
 * psmode_viewTemp.h
 *
 *  Created on: Apr 9, 2022
 *      Author: jcaf
 */

#ifndef PSMODE_VIEWTEMP_H_
#define PSMODE_VIEWTEMP_H_
int8_t psmode_viewTemp(void);


#endif /* PSMODE_VIEWTEMP_H_ */
